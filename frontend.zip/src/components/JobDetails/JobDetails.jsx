import React from 'react'

const JobDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default JobDetails
